﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace socketclient
{
  class Program
  {
    static Socket socketSend;
    static Socket socketSend1;
    private static byte[] result = new byte[1024];
    static void Main(string[] args)
    {
      socketSend = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
      IPAddress ip = IPAddress.Parse("127.0.0.1");
      IPEndPoint point = new IPEndPoint(ip, 6789);
      socketSend.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
      socketSend.Connect(point);
      socketSend.Send(Encoding.UTF8.GetBytes("test0"));
      Thread c_thread = new Thread(Received);
      c_thread.IsBackground = true;
      c_thread.Start();
      Server1.Server1Main(socketSend.LocalEndPoint.ToString().Split(":")[0],Convert.ToInt32(socketSend.LocalEndPoint.ToString().Split(":")[1]));


      Console.ReadKey();
    }
    static void Received()
    {
      while (true)
      {
        try
        {
          byte[] buffer = new byte[1024 * 1024 * 3];
          //实际接收到的有效字节数
          int len = socketSend.Receive(buffer);
          if (len == 0)
          {
            continue;
          }
          string str = Encoding.UTF8.GetString(buffer, 0, len);
          Console.WriteLine("client1 received：" + socketSend.RemoteEndPoint + ":" + str);
          if (!string.IsNullOrEmpty(str))
          {
            //尝试连接------
            socketSend1 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPAddress ip = IPAddress.Parse(str.Split(":")[0]);
            IPEndPoint point = new IPEndPoint(ip, Convert.ToInt32(str.Split(":")[1]));
            socketSend1.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            socketSend1.Connect(point);
            socketSend1.Send(Encoding.UTF8.GetBytes("wo shi 1111111111 de zhilian"));
            Thread c_thread = new Thread(Received1);
            c_thread.IsBackground = true;
            c_thread.Start();
          }
        }
        catch (Exception e)
        {
          Console.WriteLine("exp"+e.Message);

        }
      }
    }

    static void Received1()
    {
      while (true)
      {
        try
        {
          byte[] buffer = new byte[1024 * 1024 * 3];
          //实际接收到的有效字节数
          int len = socketSend1.Receive(buffer);
          if (len == 0)
          {
            continue;
          }
          string str = Encoding.UTF8.GetString(buffer, 0, len);
          Console.WriteLine("client1-------- received：" + socketSend1.RemoteEndPoint + ":" + str);

        }
        catch
        {

        }
      }
    }



  }
}
