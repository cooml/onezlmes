﻿using System;
using System.Collections.Generic;
using System.Text;

namespace onezl.iocp.com
{
    class nugetfabu
    {
// cmd文件：

//echo off
//set VERSION = 0.0.15

//dotnet build -c Release -f netcoreapp2.0 -o out

//nuget pack Comm.nuspec -Version %VERSION%
//nuget setapikey 3d933d3f-00c3-35de-a3ae-3d1542f2aef7 -source http://10.122.11.61:9081/repository/nuget-hosted/
//nuget push Comm.%VERSION%.nupkg -source http://10.122.11.61:9081/repository/nuget-hosted/








    }
}
