package com.lenovo.eservice.contents.common.db;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.WriteConcern;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;


public enum MongoUtil {
     /**
     * 定义一个枚举的元素，它代表此类的一个实例
     */
    instance;

    private static MongoClient mongoClient;
    private static String MongodbConnect=System.getenv("GITLAB.XPAAS.LENOVO.COM_ESERVICE_CONFIG_SHARED_ENV.CONNECTIONSTRING.NOSQLDB");

    static {
        System.out.println("===============MongoDBUtil init========================");
        
        mongoClient = new MongoClient(new MongoClientURI(MongodbConnect));        
        Builder options = new MongoClientOptions.Builder();
        options.cursorFinalizerEnabled(true);
        //https://github.com/mongodb/mongo-java-driver/commit/754f82e00be45d6deb22eb99ecc14b913300dff1，官方去掉了下面的两个属性
        //deprecated There is no replacement for this method.  Use the connectTimeout property to control connection timeout.
        //options.maxAutoConnectRetryTime(true);// 自动重连true
        // options.maxAutoConnectRetryTime(10); // the maximum auto connect retry time
        options.connectionsPerHost(300);// 连接池设置为300个连接,默认为100
        options.connectTimeout(50000);// 连接超时，推荐>3000毫秒
        options.maxWaitTime(5000); //
        options.socketTimeout(0);// 套接字超时时间，0无限制
        options.threadsAllowedToBlockForConnectionMultiplier(5000);// 线程队列数，如果连接线程排满了队列就会抛出“Out of semaphores to get db”错误。
        options.writeConcern(WriteConcern.SAFE);//
        options.build();
    }

    // ------------------------------------共用方法---------------------------------------------------
    
    /**
     * 获取collection对象 - 指定Collection
     * 
     * @param collName
     * @return
     */
    private MongoCollection<Document> getCollection( String collName) {
        if (null == collName || "".equals(collName)) {
            return null;
        }
        //MongoCollection<Document> collection = mongoClient.getDatabase(dbName).getCollection(collName);
        MongoCollection<Document> collection = mongoClient.getDatabase(new MongoClientURI(MongodbConnect).getDatabase()).getCollection(collName);
        return collection;
    }

   
    

    /**
     * 查找对象 - 根据主键_id
     * 
     * @param collection
     * @param id
     * @return
     */
    public Document findById(String  table, String id) {
        ObjectId _idobj = null;
        try {
            _idobj = new ObjectId(id);
        } catch (Exception e) {
            return null;
        }
        Document myDoc = getCollection(table).find(Filters.eq("_id", _idobj)).first();
        return myDoc;
    }

    

    /** 条件查询 */
    public FindIterable<Document> find(String  table,Bson filter) {
       
        return  getCollection(table).find(filter);
    }

    /** 分页查询 */
    public MongoCursor<Document> findByPage(String  table, Bson filter, int pageNo, int pageSize) {
        Bson orderBy = new BasicDBObject("_id", 1);
        return getCollection(table).find(filter).sort(orderBy).skip((pageNo - 1) * pageSize).limit(pageSize).iterator();
    }
    
    public void close() {
        if (mongoClient != null) {
            mongoClient.close();
            mongoClient = null;
        }
    }

    
}