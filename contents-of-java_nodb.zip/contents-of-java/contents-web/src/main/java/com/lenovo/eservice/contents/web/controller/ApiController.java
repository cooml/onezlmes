package com.lenovo.eservice.contents.web.controller;

import javax.servlet.http.HttpServletRequest;

import com.lenovo.eservice.contents.api.ContentsConverter;
import com.lenovo.eservice.contents.common.db.MongoUtil;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;

import org.bson.Document;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ApiController {
    
    private static final String apiversion = "api";
    @RequestMapping(value = apiversion+"/getcontent", method = { RequestMethod.GET}, produces="application/json;charset=UTF-8")
    @ResponseBody
    public String getcontent(HttpServletRequest request) {
       
       return ContentsConverter.getContent(request.getParameter("docid"));
    }

}
