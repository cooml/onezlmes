package com.lenovo.eservice.contents.api;

import com.lenovo.eservice.contents.common.db.MongoUtil;
import com.mongodb.client.FindIterable;
import com.mongodb.client.model.Filters;

import org.bson.Document;

public class ContentsConverter {
   
    public static String getContent(String docId)
    {
         FindIterable<Document> res = MongoUtil.instance.find("Contents",Filters.eq("ID", docId));
        for(Document x:res) {
			return x.toJson();
		}
        return null;
    }
   

}

