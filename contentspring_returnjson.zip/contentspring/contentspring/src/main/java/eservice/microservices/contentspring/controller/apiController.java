package eservice.microservices.contentspring.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonStreamContext;

import org.springframework.boot.test.json.JsonContent;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import eservice.microservices.dbhelper.MongoHelper;

@RestController
public class apiController {

    @RequestMapping(value = "getcontent", method = { RequestMethod.GET}, produces="application/json;charset=UTF-8")
    @ResponseBody
    public String getcontent(HttpServletRequest request) {

        String datacontent = MongoHelper.getContentFormMongo(request.getParameter("id"));
        return datacontent;
 
        // String datacontent = MongoHelper.getContentFormMongo(request.getParameter("id"));
 
        // ByteArrayOutputStream bas = new ByteArrayOutputStream();
        // bas.write(datacontent.getBytes("utf-8"));
        // response.setContentType("application/json;charset=UTF-8");
        // response.setContentLength(bas.size());
        // OutputStream os = response.getOutputStream();
        // bas.writeTo(os);
        // os.flush();






    //     response.setCharacterEncoding("UTF-8");
    //     response.setContentType("application/json; charset=utf-8");
    //     String datacontent = MongoHelper.getContentFormMongo(request.getParameter("id"));
    //     PrintWriter writer=null;
    //     try {
    //         writer = response.getWriter();
    //     } catch (IOException e) {
    //         // TODO Auto-generated catch block
    //         e.printStackTrace();
    //     }
    //    Map<String, String> map = new HashMap<>();
    //    map.put("status", "success");
    //    writer.write(datacontent);
       
    //     return datacontent;
    }

}
