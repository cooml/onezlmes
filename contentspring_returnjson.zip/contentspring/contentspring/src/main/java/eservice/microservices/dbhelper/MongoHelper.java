package eservice.microservices.dbhelper;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
public class MongoHelper {
 
	private static final Logger logger = LoggerFactory
			.getLogger(MongoHelper.class);
	
	static final String DBName = "SupportDB26";
	static final String ServerAddress = "localhost";
	static final int PORT = 27017;
 
	public MongoHelper() {
	}
 
	public static String  getContentFormMongo(String id) {
		MongoClient mongoClient = null;
		try {
			// 连接到 mongodb 服务
            mongoClient = new MongoClient(ServerAddress, PORT);
            
            logger.debug("Connect to mongodb successfully");

             MongoDatabase db = mongoClient.getDatabase("SupportDB26");
            MongoCollection<Document> doc = db.getCollection("Contents");

            FindIterable<Document> iter = doc.find(new Document("ID",id));
            String returnstr=null;
            for(Document x:iter) {
                returnstr= x.toJson();
              
              }
              mongoClient.close();

              return returnstr;


		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
		return "";
	}
 
	
}