﻿using System;
using System.Collections.Generic;
using System.Text;

namespace onezl.iocp
{
   public static class Logger
    {
    public static void WriteLog(string logmes)
    {
      Console.WriteLine("写日志：-----"+logmes);
    }
  }
}
