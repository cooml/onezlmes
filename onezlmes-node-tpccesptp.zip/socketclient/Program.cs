﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace socketclient
{
  class Program
  {
    static Socket socketSend;
    static Socket socketSend1;
    private static byte[] result = new byte[1024];
    static void Main(string[] args)
    {
      socketSend = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
      IPAddress ip = IPAddress.Parse("10.38.24.30");
      IPEndPoint point = new IPEndPoint(ip, 6789);
      socketSend.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
      socketSend.Connect(point);

      socketSend1 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
      socketSend1.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
      socketSend1.Bind(new IPEndPoint(IPAddress.Parse(socketSend.LocalEndPoint.ToString().Split(":")[0]), Convert.ToInt32(socketSend.LocalEndPoint.ToString().Split(":")[1])));

      //Server0.Server1Main(socketSend.LocalEndPoint.ToString().Split(":")[0], Convert.ToInt32(socketSend.LocalEndPoint.ToString().Split(":")[1]));

      socketSend.Send(Encoding.UTF8.GetBytes("test0"));
      Thread c_thread = new Thread(Received);
      c_thread.IsBackground = true;
      c_thread.Start();

     

      Console.ReadKey();
    }
    static void Received()
    {
      while (true)
      {
        try
        {
          byte[] buffer = new byte[1024 * 1024 * 3];
          //实际接收到的有效字节数
          int len = socketSend.Receive(buffer);
          if (len == 0)
          {
            continue;
          }
          string str = Encoding.UTF8.GetString(buffer, 0, len);
          Console.WriteLine("client0 received：" + socketSend.RemoteEndPoint + ":" + str);
          if (!string.IsNullOrEmpty(str)&& str.Split(":").Length == 2)
          {
            //尝试连接------

            IPAddress ip = IPAddress.Parse(str.Split(":")[0]);
            IPEndPoint point = new IPEndPoint(ip, Convert.ToInt32(str.Split(":")[1]));
            socketSend1.Connect(point);
            Console.WriteLine("连接1成功");
            socketSend1.Send(Encoding.UTF8.GetBytes("来自0的数据"));
            Thread c_thread = new Thread(Received1);
            c_thread.IsBackground = true;
            c_thread.Start();
          }
        }
        catch (Exception e)
        {
          Console.WriteLine("exp" + e.Message);

        }
      }
    }

    static void Received1()
    {
      while (true)
      {
        try
        {
          byte[] buffer = new byte[1024 * 1024 * 3];
          //实际接收到的有效字节数
          int len = socketSend1.Receive(buffer);
          if (len == 0)
          {
            continue;
          }
          string str = Encoding.UTF8.GetString(buffer, 0, len);
          Console.WriteLine("接收到数据：" + socketSend1.RemoteEndPoint + ":" + str);
          Thread.Sleep(1000);
          socketSend1.Send(Encoding.UTF8.GetBytes("来自0的数据" + System.DateTime.Now.ToString()));

        }
        catch
        {

        }
      }
    }



  }
}
